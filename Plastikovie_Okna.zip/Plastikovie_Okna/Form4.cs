﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Plastikovie_Okna
{
    public partial class Form4 : Form
    {
        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private DataTable dataTable;

        public Form4()
        {
            InitializeComponent();
        }

        private void bt10_Click(object sender, EventArgs e)
        {
            Glavnaya otherForm = new Glavnaya();
            otherForm.Show();
            this.Hide();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            string connectionString = "data source = stud-mssql.sttec.yar.ru,38325; initial catalog =user251_db; user id =user251_db; password =user251; MultipleActiveResultSets = True; App = EntityFramework";
            string sqlQuery = "SELECT visota_okna, shirina_okna, srok_izgotovlenia,sostoyanie_zakaza FROM [Zakazi(YP06)]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlQuery, connection);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                dgv1.DataSource = dataTable;
            }
        }

        private void dgv1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bt1_Click(object sender, EventArgs e)
        {
            string connectionString = "data source = stud-mssql.sttec.yar.ru,38325; initial catalog =user251_db; user id =user251_db; password =user251; MultipleActiveResultSets = True; App = EntityFramework";
            SqlConnection connection = new SqlConnection(connectionString);
            string visota_okna = tb1.Text;

            try
            {
                connection.Open();

                if (dgv1.SelectedCells.Count > 0)
                {
                    int rowIndex = dgv1.SelectedCells[0].RowIndex;
                    int columnIndex = dgv1.SelectedCells[0].ColumnIndex;

                    dgv1.Rows[rowIndex].Cells[columnIndex].Value = visota_okna;

                    string query = "INSERT INTO [Zakazi(YP06)] (visota_okna) VALUES (@visota_okna)";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@visota_okna", visota_okna);

                    command.ExecuteNonQuery();

                    MessageBox.Show("Данные успешно добавлены в базу данных.");
                }
                else
                {
                    MessageBox.Show("Пожалуйста, выберите ячейку для добавления данных.");
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении данных: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

  

       

        private void dgv1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form4_Load_1(object sender, EventArgs e)
        {
            string connectionString = "data source = stud-mssql.sttec.yar.ru,38325; initial catalog = user251_db; user id = user251_db; password = user251; MultipleActiveResultSets = True; App = EntityFramework";

            connection = new SqlConnection(connectionString);

            try
            {
                connection.Open();

                string query = "SELECT * FROM [Zakazi(YP06)]";

                adapter = new SqlDataAdapter(query, connection);

                dataTable = new DataTable();

                adapter.Fill(dataTable);

                dgv1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке данных из базы данных: " + ex.Message);
            }
            finally
            {
              
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }

        }

        private void bt3_Click_1(object sender, EventArgs e)
        {
            string newValue = tb2.Text;

            if (!string.IsNullOrEmpty(newValue))
            {
                if (dgv1.SelectedCells.Count > 0)
                {
                    foreach (DataGridViewCell cell in dgv1.SelectedCells)
                    {
                        if (cell.RowIndex >= 0 && cell.ColumnIndex >= 0)
                        {
                            dgv1.Rows[cell.RowIndex].Cells[cell.ColumnIndex].Value = newValue;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Пожалуйста, выберите ячейку для изменения.");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите значение для изменения.");
            }
        }

        private void bt2_Click_1(object sender, EventArgs e)
        {

            if (dgv1.SelectedCells.Count > 0 || dgv1.SelectedColumns.Count > 0)
            {
                if (dgv1.SelectedCells.Count > 0)
                {

                    foreach (DataGridViewCell cell in dgv1.SelectedCells)
                    {
                        if (cell.RowIndex >= 0)
                        {
                            dgv1.Rows.RemoveAt(cell.RowIndex);
                        }
                    }
                }
                else if (dgv1.SelectedColumns.Count > 0)
                {

                    foreach (DataGridViewColumn column in dgv1.SelectedColumns)
                    {
                        if (column.Index >= 0)
                        {
                            dgv1.Columns.RemoveAt(column.Index);
                        }
                    }
                }


            }
        }

        private void bt10_Click_1(object sender, EventArgs e)
        {
            Glavnaya otherForm = new Glavnaya ();
            otherForm.Show();
            this.Hide();
        }
    }
    }

      