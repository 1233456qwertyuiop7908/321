﻿namespace Plastikovie_Okna
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb2 = new System.Windows.Forms.TextBox();
            this.tb1 = new System.Windows.Forms.TextBox();
            this.lb2 = new System.Windows.Forms.Label();
            this.bt3 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.bt1 = new System.Windows.Forms.Button();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.bt10 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.SuspendLayout();
            // 
            // tb2
            // 
            this.tb2.Location = new System.Drawing.Point(625, 67);
            this.tb2.Name = "tb2";
            this.tb2.Size = new System.Drawing.Size(169, 20);
            this.tb2.TabIndex = 29;
            // 
            // tb1
            // 
            this.tb1.Location = new System.Drawing.Point(415, 67);
            this.tb1.Name = "tb1";
            this.tb1.Size = new System.Drawing.Size(169, 20);
            this.tb1.TabIndex = 28;
            // 
            // lb2
            // 
            this.lb2.AutoSize = true;
            this.lb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb2.Location = new System.Drawing.Point(27, 9);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(190, 25);
            this.lb2.TabIndex = 27;
            this.lb2.Text = "Личный кабинет";
            // 
            // bt3
            // 
            this.bt3.Location = new System.Drawing.Point(625, 118);
            this.bt3.Name = "bt3";
            this.bt3.Size = new System.Drawing.Size(132, 54);
            this.bt3.TabIndex = 26;
            this.bt3.Text = "Изменить";
            this.bt3.UseVisualStyleBackColor = true;
            this.bt3.Click += new System.EventHandler(this.bt3_Click_1);
            // 
            // bt2
            // 
            this.bt2.Location = new System.Drawing.Point(527, 197);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(132, 54);
            this.bt2.TabIndex = 25;
            this.bt2.Text = "Удалить";
            this.bt2.UseVisualStyleBackColor = true;
            this.bt2.Click += new System.EventHandler(this.bt2_Click_1);
            // 
            // bt1
            // 
            this.bt1.Location = new System.Drawing.Point(415, 118);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(132, 54);
            this.bt1.TabIndex = 24;
            this.bt1.Text = "Добавить";
            this.bt1.UseVisualStyleBackColor = true;
            this.bt1.Click += new System.EventHandler(this.bt1_Click);
            // 
            // dgv1
            // 
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Location = new System.Drawing.Point(32, 57);
            this.dgv1.Name = "dgv1";
            this.dgv1.Size = new System.Drawing.Size(359, 221);
            this.dgv1.TabIndex = 23;
            // 
            // bt10
            // 
            this.bt10.Location = new System.Drawing.Point(682, 255);
            this.bt10.Name = "bt10";
            this.bt10.Size = new System.Drawing.Size(75, 23);
            this.bt10.TabIndex = 22;
            this.bt10.Text = "Назад";
            this.bt10.UseVisualStyleBackColor = true;
            this.bt10.Click += new System.EventHandler(this.bt10_Click_1);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 308);
            this.Controls.Add(this.tb2);
            this.Controls.Add(this.tb1);
            this.Controls.Add(this.lb2);
            this.Controls.Add(this.bt3);
            this.Controls.Add(this.bt2);
            this.Controls.Add(this.bt1);
            this.Controls.Add(this.dgv1);
            this.Controls.Add(this.bt10);
            this.Name = "Form4";
            this.Text = "Личный кабинет";
            this.Load += new System.EventHandler(this.Form4_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb2;
        private System.Windows.Forms.TextBox tb1;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Button bt3;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.Button bt1;
        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.Button bt10;
    }
}