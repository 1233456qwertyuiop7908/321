﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Plastikovie_Okna
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void bt2_Click(object sender, EventArgs e)
        {
            Glavnaya otherForm = new Glavnaya();
            otherForm.Show();
            this.Hide();
        }

        private void chkb1_CheckedChanged(object sender, EventArgs e)
        {
            chkb1.CheckedChanged += chkb1_CheckedChanged;
            if (chkb1.Checked)
            {
                tb6.PasswordChar = '\0';
            }
            else
            {
                tb6.PasswordChar = '*';
            }
        }
        public string result(string text)
        {
            if (text == "") { return "Не заполнено"; }
            else { return text; }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tb1.Text) || string.IsNullOrEmpty(tb2.Text) || string.IsNullOrEmpty(tb5.Text) || string.IsNullOrEmpty(tb6.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
            }
            else
            {
                string conn = "data source = stud-mssql.sttec.yar.ru,38325; initial catalog =user251_db; user id =user251_db; password =user251; MultipleActiveResultSets = True; App = EntityFramework";
                using (SqlConnection sqlConnection = new SqlConnection(conn))
                {
                    sqlConnection.Open();
                    string comm = "INSERT INTO [Klient(YP06)] (Fio,telefon, login, Password) VALUES ( @Fio,@telefon,@login, @Password)";
                    using (SqlCommand sqlCommand = new SqlCommand(comm, sqlConnection))
                    {
                       
                        sqlCommand.Parameters.AddWithValue("@Fio", tb1.Text);
                        sqlCommand.Parameters.AddWithValue("@telefon", tb2.Text);
                        sqlCommand.Parameters.AddWithValue("@Login", tb5.Text);
                        sqlCommand.Parameters.AddWithValue("@Password", tb6.Text);
                        int v = sqlCommand.ExecuteNonQuery();
                    }
                    sqlConnection.Close();
                }
                Glavnaya form1 = new Glavnaya();
                form1.Close();
            }
        }

        private void tb2_TextChanged(object sender, EventArgs e)
        {
            if (tb2.Text.Length > 11)
            {
                tb2.Text = tb2.Text.Substring(0, 11);
            }
        }

        private void tb2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Доступны только цифры");
            }
        }

        private void tb1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == ' ')
            {
                e.Handled = false;
                return;
            }
            if (!IsRussianLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                MessageBox.Show("Пожалуйста, введите только русские символы");
                e.Handled = true;
            }
            else if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Пожалуйста, введите только русские символы");
                e.Handled = true;
            }
        }

        private bool IsRussianLetter(char input)
        {
            return (input >= 'А' && input <= 'я') || input == 'Ё' || input == 'ё';
        }

        private void tb5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                if (!IsLatinLetter(e.KeyChar))
                {
                    MessageBox.Show("Пожалуйста, введите только латинские символы и цифры");
                    e.Handled = true;
                }
            }
        }

        private bool IsLatinLetter(char input)
        {
            return (input >= 'a' && input <= 'z') || (input >= 'A' && input <= 'Z');
        }

        private void tb6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                if (!IsLatinLetter(e.KeyChar))
                {
                    MessageBox.Show("Пожалуйста, введите только латинские символы и цифры");
                    e.Handled = true;
                }
            }
        }

       
    }
}
