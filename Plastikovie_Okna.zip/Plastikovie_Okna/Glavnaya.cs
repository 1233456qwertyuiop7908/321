﻿using System.Collections.Generic;
using System.ComponentModel;using System;

using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Plastikovie_Okna
{
    public partial class Glavnaya : Form
    {
        public Glavnaya()
        {
            InitializeComponent();
        }

        private void Glavnaya_Load(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Form2 otherForm = new Form2();
            otherForm.Show();
            this.Hide();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            Form3 otherForm = new Form3();
            otherForm.Show();
            this.Hide();
        }
    }
}
