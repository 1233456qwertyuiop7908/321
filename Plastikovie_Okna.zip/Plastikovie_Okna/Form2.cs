﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Plastikovie_Okna
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void bt2_Click(object sender, EventArgs e)
        {
            Glavnaya otherForm = new Glavnaya();
            otherForm.Show();
            this.Hide();
        }

        private void bt1_Click(object sender, EventArgs e)
        {
            string conn = "data source = stud-mssql.sttec.yar.ru,38325; initial catalog =user251_db; user id =user251_db; password =user251; MultipleActiveResultSets = True; App = EntityFramework";
            string comm = "SELECT Login, Password FROM [Klient(YP06)] WHERE Login = '" + tb1.Text + "' and Password = '" + tb2.Text + "'";
            string log = "";
            string pass = "";

            using (SqlConnection sqlConnection = new SqlConnection(conn))
            {
                SqlCommand sqlCommand = new SqlCommand(comm, sqlConnection);
                sqlConnection.Open();
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    log = sqlDataReader.GetString(0);
                    pass = sqlDataReader.GetString(1);
                }
                if (log == tb1.Text && pass == tb2.Text)
                {

                    Form4 otherForm = new Form4();
                    otherForm.Show();
                    this.Hide();
                    MessageBox.Show("Авторизация прошла успешно!");
                }
            }

            if (tb1.Text == "admin" && tb2.Text == "admin")
            {
                MessageBox.Show("Авторизация прошла успешно!");

                Form5 form5 = new Form5();
                form5.Show();
                this.Hide();
            }
        }

        private bool IsLatinLetter(char input)
        {
            return (input >= 'a' && input <= 'z') || (input >= 'A' && input <= 'Z');
        }

        private void tb1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                if (!IsLatinLetter(e.KeyChar))
                {
                    MessageBox.Show("Пожалуйста, введите только латинские символы и цифры");
                    e.Handled = true;
                }
            }
        }

        private void tb2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                if (!IsLatinLetter(e.KeyChar))
                {
                    MessageBox.Show("Пожалуйста, введите только латинские символы и цифры");
                    e.Handled = true;
                }
            }
        }

        private void chkb1_CheckedChanged(object sender, EventArgs e)
        {
            chkb1.CheckedChanged += chkb1_CheckedChanged;
            if (chkb1.Checked)
            {
                tb2.PasswordChar = '\0';
            }
            else
            {
                tb2.PasswordChar = '*';
            }
        }
    }
}

