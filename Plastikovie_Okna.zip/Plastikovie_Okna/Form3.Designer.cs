﻿namespace Plastikovie_Okna
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb7 = new System.Windows.Forms.Label();
            this.chkb1 = new System.Windows.Forms.CheckBox();
            this.bt2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.tb6 = new System.Windows.Forms.TextBox();
            this.tb5 = new System.Windows.Forms.TextBox();
            this.tb2 = new System.Windows.Forms.TextBox();
            this.tb1 = new System.Windows.Forms.TextBox();
            this.lb6 = new System.Windows.Forms.Label();
            this.lb5 = new System.Windows.Forms.Label();
            this.lb2 = new System.Windows.Forms.Label();
            this.lb1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb7
            // 
            this.lb7.AutoSize = true;
            this.lb7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb7.Location = new System.Drawing.Point(71, 31);
            this.lb7.Name = "lb7";
            this.lb7.Size = new System.Drawing.Size(149, 25);
            this.lb7.TabIndex = 33;
            this.lb7.Text = "Регистрация";
            // 
            // chkb1
            // 
            this.chkb1.AutoSize = true;
            this.chkb1.Location = new System.Drawing.Point(32, 212);
            this.chkb1.Name = "chkb1";
            this.chkb1.Size = new System.Drawing.Size(114, 17);
            this.chkb1.TabIndex = 32;
            this.chkb1.Text = "Показать пароль";
            this.chkb1.UseVisualStyleBackColor = true;
            this.chkb1.CheckedChanged += new System.EventHandler(this.chkb1_CheckedChanged);
            // 
            // bt2
            // 
            this.bt2.Location = new System.Drawing.Point(92, 273);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(75, 23);
            this.bt2.TabIndex = 31;
            this.bt2.Text = "Назад";
            this.bt2.UseVisualStyleBackColor = true;
            this.bt2.Click += new System.EventHandler(this.bt2_Click);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(92, 244);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(78, 23);
            this.btn1.TabIndex = 30;
            this.btn1.Text = "Продолжить";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // tb6
            // 
            this.tb6.Location = new System.Drawing.Point(76, 177);
            this.tb6.Name = "tb6";
            this.tb6.PasswordChar = '*';
            this.tb6.Size = new System.Drawing.Size(157, 20);
            this.tb6.TabIndex = 29;
            // 
            // tb5
            // 
            this.tb5.Location = new System.Drawing.Point(76, 146);
            this.tb5.Name = "tb5";
            this.tb5.Size = new System.Drawing.Size(157, 20);
            this.tb5.TabIndex = 28;
            // 
            // tb2
            // 
            this.tb2.Location = new System.Drawing.Point(76, 117);
            this.tb2.Name = "tb2";
            this.tb2.Size = new System.Drawing.Size(157, 20);
            this.tb2.TabIndex = 25;
            // 
            // tb1
            // 
            this.tb1.Location = new System.Drawing.Point(76, 79);
            this.tb1.Name = "tb1";
            this.tb1.Size = new System.Drawing.Size(157, 20);
            this.tb1.TabIndex = 24;
            // 
            // lb6
            // 
            this.lb6.AutoSize = true;
            this.lb6.Location = new System.Drawing.Point(14, 180);
            this.lb6.Name = "lb6";
            this.lb6.Size = new System.Drawing.Size(45, 13);
            this.lb6.TabIndex = 23;
            this.lb6.Text = "Пароль";
            // 
            // lb5
            // 
            this.lb5.AutoSize = true;
            this.lb5.Location = new System.Drawing.Point(21, 146);
            this.lb5.Name = "lb5";
            this.lb5.Size = new System.Drawing.Size(38, 13);
            this.lb5.TabIndex = 22;
            this.lb5.Text = "Логин";
            // 
            // lb2
            // 
            this.lb2.AutoSize = true;
            this.lb2.Location = new System.Drawing.Point(12, 120);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(58, 13);
            this.lb2.TabIndex = 19;
            this.lb2.Text = "Телефона";
            // 
            // lb1
            // 
            this.lb1.AutoSize = true;
            this.lb1.Location = new System.Drawing.Point(25, 82);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(34, 13);
            this.lb1.TabIndex = 18;
            this.lb1.Text = "ФИО";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(278, 315);
            this.Controls.Add(this.lb7);
            this.Controls.Add(this.chkb1);
            this.Controls.Add(this.bt2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.tb6);
            this.Controls.Add(this.tb5);
            this.Controls.Add(this.tb2);
            this.Controls.Add(this.tb1);
            this.Controls.Add(this.lb6);
            this.Controls.Add(this.lb5);
            this.Controls.Add(this.lb2);
            this.Controls.Add(this.lb1);
            this.Name = "Form3";
            this.Text = "Регистрация";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lb7;
        private System.Windows.Forms.CheckBox chkb1;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.TextBox tb6;
        private System.Windows.Forms.TextBox tb5;
        private System.Windows.Forms.TextBox tb2;
        private System.Windows.Forms.TextBox tb1;
        private System.Windows.Forms.Label lb6;
        private System.Windows.Forms.Label lb5;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Label lb1;
    }
}